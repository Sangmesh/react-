import React, { Component } from "react";
import {NotificationContainer, NotificationManager} from 'react-notifications';
import axios from "axios";
import { Card, Header, Form, Input, Icon } from "semantic-ui-react";


let endpoint = " https://nu82q1bq7i.execute-api.ap-south-1.amazonaws.com";

class ToDoList extends Component {
  constructor(props) {
    super(props);

    this.state = {
      task_today: "",
      items: []
    };
	
	this.state = {
      task_upcoming: "",
      items: []
    };
  }

  
  
  
  componentDidMount() {
	this.getTask();
	NotificationManager.success('Success message', 'Title here');
  }

  onChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  onSubmit = () => {
	  NotificationManager.success('Success message', 'Title here');
    let { task_today } = this.state;
	let { category } = this.state;
    // console.log("pRINTING task", this.state.task);
    if (task_today) {
      axios
        .post(
          endpoint + "/putTasks",
          {
            task_today,category
          },
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded"
            }
          }
        )
        .then(res => {
          this.getTask();
          this.setState({
            task_today: ""
          });
          console.log(res);
        });
    }
  };

  getTask = () => {
    axios.get(endpoint + "/gettasks",{headers:{"BodyId":"U2FuZ2FtU2VlZ2U5ODgwMjA2MjY0"}}).then(res => {
      if (res.data) {
		
        this.setState({
          items: res.data.map(item => {
            let color = "yellow";

            if (item.status) {
              color = "green";
            }
            return (
              <Card key={item._id} color={color} fluid>
                <Card.Content>
                  <Card.Header textAlign="left">
                    <div style={{ wordWrap: "break-word" }}>{item.task}</div>
                  </Card.Header>

                  <Card.Meta textAlign="right">
                    <Icon
                      name="check circle"
                      color="green"
                      onClick={() => this.updateTask(item.id)}
                    />
                    <span style={{ paddingRight: 10 }}>Done</span>
                    <Icon
                      name="undo"
                      color="yellow"
                      onClick={() => this.undoTask(item.id)}
                    />
                    <span style={{ paddingRight: 10 }}>Undo</span>
                    <Icon
                      name="delete"
                      color="red"
                      onClick={() => this.deleteTask(item.id)}
                    />
                    <span style={{ paddingRight: 10 }}>Delete</span>
                  </Card.Meta>
                </Card.Content>
              </Card>
            );
          })
        });
      } else {
        this.setState({
          items: []
        });
      }
    });
  };

  updateTask = id => {
	 
    axios
      .put(endpoint + "/api/task/" + id, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      })
      .then(res => {
        console.log(res);
        this.getTask();
      });
  };

  undoTask = id => {
    axios
      .put(endpoint + "/api/undoTask/" + id, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      })
      .then(res => {
        console.log(res);
        this.getTask();
      });
  };

  deleteTask = id => {
	   alert(id)
    axios
      .delete(endpoint + "/api/deleteTask/" + id, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      })
      .then(res => {
        console.log(res);
        this.getTask();
      });
  };
  render() {
    return (
      <div>
        <div className="headerbar">
          <Header className="header" as="h2">
            My2doo
          </Header>
        </div>
        <div className="row">
		  <div className="col-sm-2 sidebar">
				<div class="ui list">
				<div class="item"><Icon name="dashboard" color="yellow" /> Dashboard</div>
				<div class="item"><Icon name="tasks" color="yellow" /> Create Task</div>
				<div class="item"><Icon name="stopwatch" color="yellow" />Reminder</div>
				<div class="item"><Icon name="user secret" color="yellow" /> Profile</div>
				<div class="item"><Icon name="setting" color="yellow" /> Settings</div>
		</div>
		  </div>
		  <div className="col-sm-4">
		  <div className="frame-div">
		  <div className="litle-header">Today</div>
		  <div className="outer-container">
          <Card.Group id="sortable">{this.state.items}</Card.Group>
		 </div>
		  <Form onSubmit={this.onSubmit}>
            <Input
              type="text"
              name="task_today"
              onChange={this.onChange}
              value={this.state.task_today}
              fluid
              placeholder="Create Task"
            />
			<Input
              type="hidden"
              name="category"
              value="Today"
             />
            {/* <Button >Create Task</Button> */}
          </Form>
		  </div>
		  </div>
		  <div className="col-sm-4">
          <div className="frame-div">
		  <div className="litle-header">Upcoming</div>
		  <div className="outer-container">
          <Card.Group>{this.state.items}</Card.Group>
		 </div>
		  <Form onSubmit={this.onSubmit}>
            <Input
              type="text"
              name="task_upcoming"
              onChange={this.onChange}
              value={this.state.task_upcoming}
              fluid
              placeholder="Create Task"
            />
			 <Input
              type="hidden"
              name="category"
              value={this.state.category}
             />
            {/* <Button >Create Task</Button> */}
          </Form>
		  </div>
		  
		  </div>
		  <div className="col-sm-2 sidebar" >
		  <div className="litle-header">Reminders</div>
		  
		  <div class="ui list">
				<div class="item"><Icon name="dashboard" color="yellow" /> Dashboard</div>
				<div class="item"><Icon name="tasks" color="yellow" /> Create Task</div>
				<div class="item"><Icon name="stopwatch" color="yellow" /> Set Reminder</div>
				<div class="item"><Icon name="user secret" color="yellow" /> Profile</div>
				<div class="item"><Icon name="setting" color="yellow" /> Settings</div>
		</div>
		  
		  
		  </div>
		  
        </div>
      </div>
    );
  }
}

export default ToDoList;

